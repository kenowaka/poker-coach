import Foundation

enum PokerEngine {
    struct Score: Comparable {
        let category: Int
        let kickers: [Int]

        static func < (lhs: Score, rhs: Score) -> Bool {
            if lhs.category != rhs.category { return lhs.category < rhs.category }
            for (left, right) in zip(lhs.kickers, rhs.kickers) where left != right {
                return left < right
            }
            return lhs.kickers.count < rhs.kickers.count
        }
    }

    static func analyze(holeCards: [Card], board: [Card], pot: Double, callAmount: Double, simulations: Int = 7_000) -> HandAnalysis? {
        let known = holeCards + board
        guard holeCards.count == 2, Set(known).count == known.count, board.count <= 5 else { return nil }

        let equity = estimateEquity(holeCards: holeCards, board: board, simulations: simulations)
        let potOdds = callAmount > 0 ? callAmount / max(0.01, pot + callAmount) : 0
        let edge = equity - potOdds
        let recommendation: String
        if callAmount == 0 {
            recommendation = equity >= 0.60 ? "Можно ставить для вэлью" : "Чек — спокойная линия"
        } else if edge >= 0.08 {
            recommendation = "Колл выгоден по шансам банка"
        } else if edge >= 0 {
            recommendation = "Пограничный колл"
        } else {
            recommendation = "Фолд по базовой математике"
        }

        return HandAnalysis(
            holeCards: holeCards,
            board: board,
            pot: pot,
            callAmount: callAmount,
            equity: equity,
            potOdds: potOdds,
            madeHand: madeHandName(cards: known),
            recommendation: recommendation
        )
    }

    static func estimateEquity(holeCards: [Card], board: [Card], simulations: Int) -> Double {
        let known = Set(holeCards + board)
        let deck = fullDeck.filter { !known.contains($0) }
        let missingBoard = 5 - board.count
        guard deck.count >= missingBoard + 2, simulations > 0 else { return 0 }

        var wins = 0.0
        for _ in 0..<simulations {
            let drawn = Array(deck.shuffled().prefix(missingBoard + 2))
            let finalBoard = board + Array(drawn.prefix(missingBoard))
            let opponent = Array(drawn.dropFirst(missingBoard).prefix(2))
            let heroScore = bestScore(cards: holeCards + finalBoard)
            let opponentScore = bestScore(cards: opponent + finalBoard)
            if heroScore > opponentScore { wins += 1 }
            if heroScore == opponentScore { wins += 0.5 }
        }
        return wins / Double(simulations)
    }

    static func madeHandName(cards: [Card]) -> String {
        guard cards.count >= 5 else {
            if cards.count >= 2, cards[0].rank == cards[1].rank { return "Карманная пара" }
            return "Старшая карта"
        }
        switch bestScore(cards: cards).category {
        case 8: return "Стрит-флеш"
        case 7: return "Каре"
        case 6: return "Фулл-хаус"
        case 5: return "Флеш"
        case 4: return "Стрит"
        case 3: return "Сет"
        case 2: return "Две пары"
        case 1: return "Пара"
        default: return "Старшая карта"
        }
    }

    static func bestScore(cards: [Card]) -> Score {
        guard cards.count >= 5 else {
            let ranks = cards.map(\.rank.rawValue).sorted(by: >)
            return Score(category: 0, kickers: ranks)
        }
        var best = Score(category: -1, kickers: [])
        for combination in combinations(cards, choose: 5) {
            best = max(best, scoreFive(combination))
        }
        return best
    }

    private static func scoreFive(_ cards: [Card]) -> Score {
        let ranks = cards.map(\.rank.rawValue).sorted(by: >)
        let rankGroups: [Int: [Int]] = Dictionary(grouping: ranks) { rank in rank }
        var grouped: [(rank: Int, count: Int)] = rankGroups.map { entry in
            (rank: entry.key, count: entry.value.count)
        }
        grouped.sort { left, right in
            if left.count == right.count { return left.rank > right.rank }
            return left.count > right.count
        }
        let flush = Set(cards.map(\.suit)).count == 1
        let straightHigh = straightHighCard(ranks)

        if flush, let high = straightHigh { return Score(category: 8, kickers: [high]) }
        if grouped[0].count == 4 {
            return Score(category: 7, kickers: [grouped[0].rank, grouped[1].rank])
        }
        if grouped[0].count == 3, grouped[1].count == 2 {
            return Score(category: 6, kickers: [grouped[0].rank, grouped[1].rank])
        }
        if flush { return Score(category: 5, kickers: ranks) }
        if let high = straightHigh { return Score(category: 4, kickers: [high]) }
        if grouped[0].count == 3 {
            let remaining = grouped.dropFirst().map { item in item.rank }.sorted(by: >)
            return Score(category: 3, kickers: [grouped[0].rank] + remaining)
        }
        let pairs = grouped.filter { item in item.count == 2 }.map { item in item.rank }.sorted(by: >)
        if pairs.count >= 2 {
            let kicker = grouped.first { $0.count == 1 }?.rank ?? 0
            return Score(category: 2, kickers: Array(pairs.prefix(2)) + [kicker])
        }
        if let pair = pairs.first {
            let kickers = grouped.filter { item in item.count == 1 }.map { item in item.rank }.sorted(by: >)
            return Score(category: 1, kickers: [pair] + kickers)
        }
        return Score(category: 0, kickers: ranks)
    }

    private static func straightHighCard(_ ranks: [Int]) -> Int? {
        var unique = Array(Set(ranks)).sorted(by: >)
        if unique.contains(14) { unique.append(1) }
        guard unique.count >= 5 else { return nil }
        for index in 0...(unique.count - 5) {
            let slice = Array(unique[index..<(index + 5)])
            if zip(slice, slice.dropFirst()).allSatisfy({ $0.0 - $0.1 == 1 }) { return slice[0] }
        }
        return nil
    }

    private static func combinations<T>(_ source: [T], choose count: Int) -> [[T]] {
        if count == 0 { return [[]] }
        guard source.count >= count else { return [] }
        if source.count == count { return [source] }
        let head = source[0]
        let tail = Array(source.dropFirst())
        return combinations(tail, choose: count - 1).map { [head] + $0 } + combinations(tail, choose: count)
    }

    private static let fullDeck: [Card] = Suit.allCases.flatMap { suit in
        Rank.allCases.map { Card(rank: $0, suit: suit) }
    }
}
