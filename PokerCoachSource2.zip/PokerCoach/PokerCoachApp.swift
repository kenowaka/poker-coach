import SwiftUI

@main
struct PokerCoachApp: App {
    @StateObject private var historyStore = HistoryStore()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(historyStore)
                .preferredColorScheme(.dark)
        }
    }
}
