import Foundation

struct ParsedHandInput {
    var cards: [Card] = []
    var pot: Double?
    var callAmount: Double?
}

enum VoiceHandParser {
    static func parse(_ source: String) -> ParsedHandInput {
        let text = normalize(source)
        let tokens = text.split(separator: " ").map(String.init)
        var result = ParsedHandInput()

        for index in tokens.indices {
            if let rank = rank(from: tokens[index]) {
                for suitIndex in (index + 1)..<min(tokens.count, index + 4) {
                    if let suit = suit(from: tokens[suitIndex]) {
                        let card = Card(rank: rank, suit: suit)
                        if !result.cards.contains(card) { result.cards.append(card) }
                        break
                    }
                }
            }

            if ["банк", "банке", "пот"].contains(tokens[index]) {
                result.pot = nearbyNumber(tokens: tokens, after: index)
            }
            if ["ставка", "колл", "доколлить", "доставить"].contains(tokens[index]) {
                result.callAmount = nearbyNumber(tokens: tokens, after: index)
            }
        }
        return result
    }

    private static func normalize(_ text: String) -> String {
        text.lowercased()
            .replacingOccurrences(of: "ё", with: "е")
            .components(separatedBy: CharacterSet.letters.union(.decimalDigits).union(CharacterSet(charactersIn: ",.")).inverted)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
    }

    private static func nearbyNumber(tokens: [String], after index: Int) -> Double? {
        let upperBound = min(tokens.count, index + 4)
        for token in tokens[(index + 1)..<upperBound] {
            if let value = Double(token.replacingOccurrences(of: ",", with: ".")) { return value }
        }
        return nil
    }

    private static func rank(from word: String) -> Rank? {
        let values: [String: Rank] = [
            "2": .two, "двойка": .two, "два": .two,
            "3": .three, "тройка": .three, "три": .three,
            "4": .four, "четверка": .four, "четыре": .four,
            "5": .five, "пятерка": .five, "пять": .five,
            "6": .six, "шестерка": .six, "шесть": .six,
            "7": .seven, "семерка": .seven, "семь": .seven,
            "8": .eight, "восьмерка": .eight, "восемь": .eight,
            "9": .nine, "девятка": .nine, "девять": .nine,
            "10": .ten, "десятка": .ten, "десять": .ten,
            "валет": .jack, "дама": .queen, "король": .king, "туз": .ace
        ]
        return values[word]
    }

    private static func suit(from word: String) -> Suit? {
        if word.hasPrefix("пик") { return .spades }
        if word.hasPrefix("черв") { return .hearts }
        if word.hasPrefix("буб") { return .diamonds }
        if word.hasPrefix("треф") || word.hasPrefix("крест") { return .clubs }
        return nil
    }
}
