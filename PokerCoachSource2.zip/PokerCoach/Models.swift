import Foundation

enum Suit: String, CaseIterable, Codable, Identifiable {
    case spades = "♠"
    case hearts = "♥"
    case diamonds = "♦"
    case clubs = "♣"

    var id: String { rawValue }
    var isRed: Bool { self == .hearts || self == .diamonds }
}

enum Rank: Int, CaseIterable, Codable, Identifiable, Comparable {
    case two = 2, three, four, five, six, seven, eight, nine, ten, jack, queen, king, ace

    var id: Int { rawValue }
    var label: String {
        switch self {
        case .jack: return "J"
        case .queen: return "Q"
        case .king: return "K"
        case .ace: return "A"
        default: return String(rawValue)
        }
    }

    static func < (lhs: Rank, rhs: Rank) -> Bool { lhs.rawValue < rhs.rawValue }
}

struct Card: Hashable, Codable, Identifiable {
    let rank: Rank
    let suit: Suit
    var id: String { "\(rank.rawValue)-\(suit.rawValue)" }
    var label: String { "\(rank.label)\(suit.rawValue)" }
}

struct HandAnalysis: Codable, Identifiable {
    let id: UUID
    let createdAt: Date
    let holeCards: [Card]
    let board: [Card]
    let pot: Double
    let callAmount: Double
    let equity: Double
    let potOdds: Double
    let madeHand: String
    let recommendation: String

    init(holeCards: [Card], board: [Card], pot: Double, callAmount: Double, equity: Double, potOdds: Double, madeHand: String, recommendation: String) {
        self.id = UUID()
        self.createdAt = Date()
        self.holeCards = holeCards
        self.board = board
        self.pot = pot
        self.callAmount = callAmount
        self.equity = equity
        self.potOdds = potOdds
        self.madeHand = madeHand
        self.recommendation = recommendation
    }
}

struct CardSlot: Identifiable, Equatable {
    let id: String
    var rank: Rank
    var suit: Suit
    var isEnabled: Bool

    var card: Card { Card(rank: rank, suit: suit) }
}
