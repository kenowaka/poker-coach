import SwiftUI
import Foundation

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationStack { NewHandView() }
                .tabItem { Label("Раздача", systemImage: "suit.spade.fill") }
            NavigationStack { HistoryView() }
                .tabItem { Label("История", systemImage: "clock.arrow.circlepath") }
            NavigationStack { SetupView() }
                .tabItem { Label("Очки", systemImage: "eyeglasses") }
        }
        .tint(Theme.lime)
    }
}

private enum Theme {
    static let felt = Color(red: 0.035, green: 0.13, blue: 0.105)
    static let panel = Color(red: 0.07, green: 0.19, blue: 0.155)
    static let lime = Color(red: 0.77, green: 0.93, blue: 0.45)
    static let cream = Color(red: 0.95, green: 0.94, blue: 0.87)
    static let muted = Color(red: 0.59, green: 0.70, blue: 0.64)
}

struct NewHandView: View {
    @EnvironmentObject private var history: HistoryStore
    @StateObject private var audio = AudioCoach()
    @State private var holeCards = [
        CardSlot(id: "hole-1", rank: .ace, suit: .spades, isEnabled: true),
        CardSlot(id: "hole-2", rank: .king, suit: .spades, isEnabled: true)
    ]
    @State private var boardCards = [
        CardSlot(id: "flop-1", rank: .two, suit: .clubs, isEnabled: true),
        CardSlot(id: "flop-2", rank: .seven, suit: .diamonds, isEnabled: true),
        CardSlot(id: "flop-3", rank: .queen, suit: .hearts, isEnabled: true),
        CardSlot(id: "turn", rank: .three, suit: .spades, isEnabled: false),
        CardSlot(id: "river", rank: .four, suit: .clubs, isEnabled: false)
    ]
    @State private var pot = "20"
    @State private var callAmount = "10"
    @State private var result: HandAnalysis?
    @State private var isCalculating = false
    @State private var showInvalidCards = false

    var body: some View {
        ZStack {
            Theme.felt.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    header
                    voicePanel
                    cardPanel
                    numbersPanel
                    analyzeButton
                    if let result { ResultCard(analysis: result) }
                }
                .padding(18)
            }
        }
        .navigationTitle("Poker Coach")
        .navigationBarTitleDisplayMode(.inline)
        .task { await audio.requestPermissions() }
        .alert("Одна карта выбрана дважды", isPresented: $showInvalidCards) {
            Button("Понятно", role: .cancel) { }
        } message: {
            Text("Измени масть или достоинство повторяющейся карты.")
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("УЧЕБНАЯ РАЗДАЧА")
                .font(.caption.weight(.bold))
                .tracking(2)
                .foregroundStyle(Theme.lime)
            Text("Решение через математику,\nа не догадки.")
                .font(.system(size: 32, weight: .black, design: .rounded))
                .foregroundStyle(Theme.cream)
        }
        .accessibilityElement(children: .combine)
    }

    private var voicePanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label(audio.isListening ? "Слушаю…" : "Голосовой ввод", systemImage: audio.isListening ? "waveform" : "mic.fill")
                    .font(.headline)
                Spacer()
                Button(action: audio.toggleListening) {
                    Image(systemName: audio.isListening ? "stop.fill" : "mic.fill")
                        .frame(width: 44, height: 44)
                        .background(audio.isListening ? Color.red : Theme.lime)
                        .foregroundStyle(Color.black)
                        .clipShape(Circle())
                }
                .accessibilityLabel(audio.isListening ? "Остановить запись" : "Начать голосовой ввод")
            }
            Text(audio.transcript.isEmpty ? "Например: туз пик, король пик, двойка треф… банк 20, ставка 10" : audio.transcript)
                .font(.subheadline)
                .foregroundStyle(audio.transcript.isEmpty ? Theme.muted : Theme.cream)
            if !audio.transcript.isEmpty {
                Button("Заполнить из фразы", action: applyTranscript)
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(Theme.lime)
            }
            if let error = audio.errorMessage {
                Text(error).font(.caption).foregroundStyle(.orange)
            }
        }
        .padding(16)
        .background(Theme.panel, in: RoundedRectangle(cornerRadius: 22))
    }

    private var cardPanel: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("КАРТЫ").sectionLabel()
            Text("Рука").font(.headline).foregroundStyle(Theme.cream)
            HStack(spacing: 10) {
                ForEach($holeCards) { $slot in CardPicker(slot: $slot) }
            }
            Divider().overlay(Theme.muted.opacity(0.25))
            HStack {
                Text("Борд").font(.headline).foregroundStyle(Theme.cream)
                Spacer()
                Button("Очистить") {
                    for index in boardCards.indices { boardCards[index].isEnabled = false }
                }
                .font(.caption.weight(.semibold))
                .foregroundStyle(Theme.muted)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach($boardCards) { $slot in CardPicker(slot: $slot, canDisable: true) }
                }
            }
        }
        .padding(16)
        .background(Theme.panel, in: RoundedRectangle(cornerRadius: 22))
    }

    private var numbersPanel: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("БАНК И РЕШЕНИЕ").sectionLabel()
            HStack(spacing: 12) {
                NumberField(title: "Банк до колла", text: $pot)
                NumberField(title: "Сколько добавить", text: $callAmount)
            }
        }
        .padding(16)
        .background(Theme.panel, in: RoundedRectangle(cornerRadius: 22))
    }

    private var analyzeButton: some View {
        Button(action: analyze) {
            HStack {
                if isCalculating { ProgressView().tint(.black) }
                Text(isCalculating ? "Считаю…" : "Разобрать раздачу")
                Spacer()
                Image(systemName: "arrow.right")
            }
            .font(.headline)
            .padding(.horizontal, 18)
            .frame(minHeight: 56)
            .background(Theme.lime, in: RoundedRectangle(cornerRadius: 18))
            .foregroundStyle(.black)
        }
        .disabled(isCalculating)
    }

    private func applyTranscript() {
        let parsed = VoiceHandParser.parse(audio.transcript)
        if parsed.cards.count >= 2 {
            holeCards[0].rank = parsed.cards[0].rank
            holeCards[0].suit = parsed.cards[0].suit
            holeCards[1].rank = parsed.cards[1].rank
            holeCards[1].suit = parsed.cards[1].suit
            for index in boardCards.indices {
                let parsedIndex = index + 2
                if parsed.cards.indices.contains(parsedIndex) {
                    boardCards[index].rank = parsed.cards[parsedIndex].rank
                    boardCards[index].suit = parsed.cards[parsedIndex].suit
                    boardCards[index].isEnabled = true
                } else {
                    boardCards[index].isEnabled = false
                }
            }
        }
        if let value = parsed.pot { pot = String(format: "%g", value) }
        if let value = parsed.callAmount { callAmount = String(format: "%g", value) }
    }

    private func analyze() {
        let hole = holeCards.map(\.card)
        let board = boardCards.filter(\.isEnabled).map(\.card)
        guard Set(hole + board).count == hole.count + board.count else {
            showInvalidCards = true
            return
        }
        isCalculating = true
        let potValue = Double(pot.replacingOccurrences(of: ",", with: ".")) ?? 0
        let callValue = Double(callAmount.replacingOccurrences(of: ",", with: ".")) ?? 0
        Task.detached {
            let analysis = PokerEngine.analyze(holeCards: hole, board: board, pot: potValue, callAmount: callValue)
            await MainActor.run {
                result = analysis
                isCalculating = false
                if let analysis {
                    history.add(analysis)
                    let equity = Int((analysis.equity * 100).rounded())
                    let odds = Int((analysis.potOdds * 100).rounded())
                    audio.speak("\(analysis.madeHand). Эквити \(equity) процентов. Нужно \(odds) процентов. \(analysis.recommendation).")
                }
            }
        }
    }
}

private struct CardPicker: View {
    @Binding var slot: CardSlot
    var canDisable = false

    var body: some View {
        VStack(spacing: 2) {
            if canDisable {
                Button(slot.isEnabled ? "Убрать" : "Добавить") { slot.isEnabled.toggle() }
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(slot.isEnabled ? Theme.muted : Theme.lime)
                    .frame(minHeight: 26)
            }
            Menu {
                Picker("Достоинство", selection: $slot.rank) {
                    ForEach(Rank.allCases) { rank in Text(rank.label).tag(rank) }
                }
            } label: {
                Text(slot.isEnabled ? slot.rank.label : "–")
                    .font(.system(size: 25, weight: .black, design: .rounded))
                    .frame(width: 54, height: 36)
            }
            Menu {
                Picker("Масть", selection: $slot.suit) {
                    ForEach(Suit.allCases) { suit in Text(suit.rawValue).tag(suit) }
                }
            } label: {
                Text(slot.isEnabled ? slot.suit.rawValue : " ")
                    .font(.title2)
                    .foregroundStyle(slot.suit.isRed ? Color.red.opacity(0.85) : Color.primary)
                    .frame(width: 54, height: 32)
            }
        }
        .opacity(slot.isEnabled ? 1 : 0.45)
        .frame(width: 62, height: canDisable ? 104 : 78)
        .background(Theme.cream, in: RoundedRectangle(cornerRadius: 13))
        .foregroundStyle(.black)
        .accessibilityElement(children: .contain)
    }
}

private struct NumberField: View {
    let title: String
    @Binding var text: String

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.caption).foregroundStyle(Theme.muted)
            TextField("0", text: $text)
                .keyboardType(.decimalPad)
                .font(.title2.monospacedDigit().weight(.bold))
                .padding(12)
                .background(Theme.felt, in: RoundedRectangle(cornerRadius: 12))
                .foregroundStyle(Theme.cream)
        }
    }
}

private struct ResultCard: View {
    let analysis: HandAnalysis

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text(analysis.madeHand.uppercased()).sectionLabel()
                    Text(analysis.recommendation)
                        .font(.title3.weight(.bold))
                        .foregroundStyle(Theme.cream)
                }
                Spacer()
                Image(systemName: analysis.equity >= analysis.potOdds ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .font(.title)
                    .foregroundStyle(analysis.equity >= analysis.potOdds ? Theme.lime : .orange)
            }
            HStack(spacing: 10) {
                Metric(value: analysis.equity, title: "Эквити")
                Metric(value: analysis.potOdds, title: "Нужно")
                Metric(value: analysis.equity - analysis.potOdds, title: "Запас", signed: true)
            }
            Text("Расчёт против одной случайной руки. Это учебная оценка, а не полный GTO-анализ диапазонов.")
                .font(.caption)
                .foregroundStyle(Theme.muted)
        }
        .padding(18)
        .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(Theme.lime.opacity(0.35)))
    }
}

private struct Metric: View {
    let value: Double
    let title: String
    var signed = false

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("\(signed && value > 0 ? "+" : "")\(Int((value * 100).rounded()))%")
                .font(.title3.monospacedDigit().weight(.black))
                .foregroundStyle(Theme.cream)
            Text(title).font(.caption2).foregroundStyle(Theme.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct HistoryView: View {
    @EnvironmentObject private var history: HistoryStore

    var body: some View {
        ZStack {
            Theme.felt.ignoresSafeArea()
            if history.items.isEmpty {
                ContentUnavailableView("История пуста", systemImage: "rectangle.stack", description: Text("Разобранные раздачи появятся здесь."))
            } else {
                List {
                    ForEach(history.items) { item in
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Text(item.holeCards.map(\.label).joined(separator: "  ")).font(.title3.weight(.black))
                                Spacer()
                                Text(item.createdAt, style: .date).font(.caption).foregroundStyle(.secondary)
                            }
                            Text(item.recommendation).font(.subheadline.weight(.semibold))
                            Text("Эквити \(Int(item.equity * 100))% · нужно \(Int(item.potOdds * 100))% · \(item.madeHand)")
                                .font(.caption).foregroundStyle(.secondary)
                        }
                        .padding(.vertical, 6)
                        .listRowBackground(Theme.panel)
                    }
                }
                .scrollContentBackground(.hidden)
            }
        }
        .navigationTitle("История")
        .toolbar {
            if !history.items.isEmpty {
                Button("Очистить", role: .destructive, action: history.clear)
            }
        }
    }
}

struct SetupView: View {
    var body: some View {
        ZStack {
            Theme.felt.ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Image(systemName: "eyeglasses")
                        .font(.system(size: 52, weight: .semibold))
                        .foregroundStyle(Theme.lime)
                    Text("Ray‑Ban Meta\nработают как гарнитура")
                        .font(.system(size: 30, weight: .black, design: .rounded))
                        .foregroundStyle(Theme.cream)
                    SetupStep(number: "01", title: "Подключи очки", detail: "Открой Настройки → Bluetooth и убедись, что Ray‑Ban Meta подключены.")
                    SetupStep(number: "02", title: "Разреши микрофон", detail: "При первом запуске разреши приложению микрофон и распознавание речи.")
                    SetupStep(number: "03", title: "Проверь звук", detail: "Запусти разбор. Короткий ответ должен прозвучать через динамики очков.")
                    Text("Приложение не получает изображение с камеры очков и не изменяет их прошивку.")
                        .font(.footnote).foregroundStyle(Theme.muted)
                }
                .padding(22)
            }
        }
        .navigationTitle("Подключение")
    }
}

private struct SetupStep: View {
    let number: String
    let title: String
    let detail: String

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            Text(number).font(.caption.monospacedDigit().weight(.black)).foregroundStyle(Theme.lime).padding(.top, 3)
            VStack(alignment: .leading, spacing: 5) {
                Text(title).font(.headline).foregroundStyle(Theme.cream)
                Text(detail).font(.subheadline).foregroundStyle(Theme.muted)
            }
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Theme.panel, in: RoundedRectangle(cornerRadius: 18))
    }
}

private extension Text {
    func sectionLabel() -> some View {
        font(.caption.weight(.bold)).tracking(1.5).foregroundStyle(Theme.lime)
    }
}
