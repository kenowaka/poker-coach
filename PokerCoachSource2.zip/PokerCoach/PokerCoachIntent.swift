import AppIntents
import Foundation

@available(iOS 16.0, *)
struct AnalyzePokerHandIntent: AppIntent {
    static var title: LocalizedStringResource = "Разобрать покерную раздачу"
    static var description = IntentDescription("Рассчитывает equity и шансы банка по продиктованной раздаче.")
    static var openAppWhenRun = false
    static var authenticationPolicy: IntentAuthenticationPolicy = .alwaysAllowed

    @Parameter(
        title: "Раздача",
        description: "Например: туз пик, король пик, флоп двойка треф, семёрка бубен, дама червей, банк двадцать, ставка десять",
        requestValueDialog: "Опиши карты, банк и сумму колла"
    )
    var handDescription: String

    static var parameterSummary: some ParameterSummary {
        Summary("Разобрать: \(.$handDescription)")
    }

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let parsed = VoiceHandParser.parse(handDescription)
        guard parsed.cards.count >= 2 else {
            return .result(dialog: "Я не распознал две карманные карты. Назови, например: туз пик, король пик.")
        }

        let holeCards = Array(parsed.cards.prefix(2))
        let board = Array(parsed.cards.dropFirst(2).prefix(5))
        guard let analysis = PokerEngine.analyze(
            holeCards: holeCards,
            board: board,
            pot: parsed.pot ?? 0,
            callAmount: parsed.callAmount ?? 0,
            simulations: 5_000
        ) else {
            return .result(dialog: "Не удалось разобрать карты. Проверь, что одна карта не названа дважды.")
        }

        let equity = Int((analysis.equity * 100).rounded())
        let required = Int((analysis.potOdds * 100).rounded())
        return .result(dialog: "\(analysis.madeHand). Эквити \(equity) процентов. Нужно \(required) процентов. \(analysis.recommendation).")
    }
}

@available(iOS 16.0, *)
struct PokerCoachShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: AnalyzePokerHandIntent(),
            phrases: [
                "Разбор в \(.applicationName)",
                "Разобрать раздачу в \(.applicationName)",
                "Покерный расчёт в \(.applicationName)"
            ],
            shortTitle: "Разобрать раздачу",
            systemImageName: "suit.spade.fill"
        )
    }
}
