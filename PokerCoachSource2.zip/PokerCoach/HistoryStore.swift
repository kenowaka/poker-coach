import Foundation
import Combine

@MainActor
final class HistoryStore: ObservableObject {
    @Published private(set) var items: [HandAnalysis] = []
    private let storageKey = "pokerCoach.history.v1"

    init() { load() }

    func add(_ analysis: HandAnalysis) {
        items.insert(analysis, at: 0)
        if items.count > 100 { items = Array(items.prefix(100)) }
        save()
    }

    func clear() {
        items = []
        save()
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([HandAnalysis].self, from: data) else { return }
        items = decoded
    }

    private func save() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }
}
